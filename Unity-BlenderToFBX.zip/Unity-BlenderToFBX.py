blender249 = True

try: import Blender
except:
	blender249 = False
	import bpy	

if blender249:
	try: import export_fbx
	except:
		print('error: export_fbx not found.')
		Blender.Quit()
else:
	try: import io_scene_fbx.export_fbx
	except:
		print('error: io_scene_fbx.export_fbx not found.')
		# This might need to be bpy.Quit()
		raise

# Find the Blender output file
import os
outfile = os.getenv("UNITY_BLENDER_EXPORTER_OUTPUT_FILE")

# Do the conversion
print("Starting blender to FBX conversion " + outfile)

if blender249:
	export_fbx.write(outfile,
	EXP_OBS_SELECTED=False,
	EXP_MESH=True,
	EXP_MESH_APPLY_MOD=True,
	EXP_MESH_HQ_NORMALS=True,
	EXP_ARMATURE=True,
	EXP_LAMP=True,
	EXP_CAMERA=True,
	EXP_EMPTY=True,
	EXP_IMAGE_COPY=False,
	ANIM_ENABLE=True,
	ANIM_OPTIMIZE=False,
	ANIM_ACTION_ALL=True,
	GLOBAL_MATRIX = Blender.Mathutils.RotationMatrix( -90, 4, 'x' ),\
	)
else:
	import math
	from mathutils import Matrix
	# -90 degrees
	mtx4_x90n = Matrix.Rotation(-math.pi / 2.0, 4, 'X')
	
	class FakeOp:
		def report(self, tp, msg):
			print("%s: %s" % (tp, msg))
	
	io_scene_fbx.export_fbx.save(
	FakeOp(), 
	bpy.context, 
	filepath=outfile,
	use_selection=False,
	batch_mode='OFF',
	BATCH_OWN_DIR=False,
	GLOBAL_MATRIX=mtx4_x90n,
	context_objects=None,
	object_types={'EMPTY', 'ARMATURE', 'MESH'},
	mesh_apply_modifiers=True,
	mesh_smooth_type='FACE',
	ANIM_ENABLE=True,
	ANIM_OPTIMIZE=False,
	ANIM_OPTIMIZE_PRECISSION=6,
	ANIM_ACTION_ALL=True,
	use_metadata=True,
	path_mode='AUTO'	
	)

print("Finished blender to FBX conversion " + outfile)
